console.log("Here");
ReactDOM.render(
    React.createElement(Clock, null), 
    document.getElementById('content')
    );